#ifndef H_ESCREVERNATELA_
#define H_ESCREVERNATELA_
#include <stdio.h>

void binarioNaTela1(char *nomeArquivoBinario);
void trim(char *str);
void scan_quote_string(char *str);

#endif